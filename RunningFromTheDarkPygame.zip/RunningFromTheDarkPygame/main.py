"""
Step 1: Create background and title and stuff
Step 2: Create tile/levels for game
Step 3: Create player
Step 4: Add movement for player
Step 5: Add collision for player
Step 6: Add obstacles
Step 7: Add flag
Step 8: Add multiple levels
Step 9: Add lever/light on-off
Step 10: Create start screen
"""

import pygame
from pygame.locals import *
# used to get level data
import pickle

# initialize pygame
pygame.init()

# create screen
screen_width = 1000
screen_height = 700
screen = pygame.display.set_mode((screen_width, screen_height))

# set game variables
tile_size = 50
game_state = 1
level = 1
dark_state = 0
dark_img = pygame.image.load("assets/darkscreen.png")

# set custom game window
pygame.display.set_caption("Running From The Dark")
icon = pygame.image.load("assets/switchlogo.png")
pygame.display.set_icon(icon)

# custom moving checkered background
bg_img = pygame.image.load("assets/background.png")
bg_xpos = 0
bg_ypos = 0
def runbackground():
    global bg_xpos, bg_ypos
    screen.blit(bg_img, (bg_xpos, bg_ypos))
    bg_ypos -= 0.5
    if bg_ypos < -700:
        bg_ypos = 0

class Start():
    def __init__(self, x, y):
        self.image = pygame.image.load("assets/menuscreen.png")
        self.rect = self.image.get_rect()
        self.rect.x = x
        self.rect.y = y

    def draw(self):
        screen.blit(self.image, self.rect)
        return True  # Ensure the start screen is properly drawn

class Player():
    # creates player image as well as rectangle for collision
    def __init__(self, x, y):
        player_img = pygame.image.load("assets/player.png")
        self.image = pygame.transform.scale(player_img, (40, 80))
        self.rect = self.image.get_rect()
        self.rect.x = x
        self.rect.y = y
        self.width = self.image.get_width()
        self.height = self.image.get_height()
        self.vel_y = 0
        self.on_ground = False
    
    # draws player as well as controls movement
    def update(self, game_state, dark_state):
        deltax = 0
        deltay = 0
        if game_state == 0:
            key = pygame.key.get_pressed()
            if key[pygame.K_LEFT]:
                deltax -= 6
            if key[pygame.K_RIGHT]:
                deltax += 6
            # if the key is pressed, and you just clicked the button, jump
            if key[pygame.K_UP] and self.on_ground:
                self.vel_y = -16

            self.vel_y += 1
            if self.vel_y > 10:
                self.vel_y = 10
            deltay += self.vel_y

            self.on_ground = False

            # collision detection
            for tile in world.tile_list:
                # collision detection for x direction
                if tile[1].colliderect(self.rect.x + deltax, self.rect.y, self.width, self.height):
                    deltax = 0
                # collision detection for y direction
                if tile[1].colliderect(self.rect.x, self.rect.y + deltay, self.width, self.height):
                    # check if hitting head
                    if self.vel_y < 0:
                        deltay = tile[1].bottom - self.rect.top
                        self.vel_y = 0
                    # check if falling into ground
                    elif self.vel_y >= 0:
                        deltay = tile[1].top - self.rect.bottom
                        self.vel_y = 0
                        self.on_ground = True

            # check for collision with spikes
            if pygame.sprite.spritecollide(self, spike_group, False):
                self.rect.x = 100
                self.rect.y = 530

            # check collision with flag
            if pygame.sprite.spritecollide(self, flag_group, False):
                game_state = 2
                self.rect.x = 100
                self.rect.y = 530

            # check collision with lever
            if pygame.sprite.spritecollide(self, lever_group, False):
                dark_state = 1
            else:
                dark_state = 0

            self.rect.x += deltax
            self.rect.y += deltay

        screen.blit(self.image, self.rect)
        return game_state, dark_state

class World():
    def __init__(self, data):
        self.tile_list = []
        # create block
        crate_img = pygame.image.load("assets/tile.png")
        # creates the playing board as well as rectangles for each tile for collision
        row_num = 0
        for row in data:
            column_num = 0
            for tile in row:
                if tile == 1:
                    img = pygame.transform.scale(crate_img, (tile_size, tile_size))
                    tile_rect = img.get_rect()
                    tile_rect.x = column_num * tile_size
                    tile_rect.y = row_num * tile_size
                    tile = (img, tile_rect)
                    self.tile_list.append(tile)
                if tile == 2:
                    spike = Spike(column_num * tile_size, row_num * tile_size + int(tile_size / 3))
                    spike_group.add(spike)
                if tile == 3:
                    flag = Flag(column_num * tile_size, row_num * tile_size)
                    flag_group.add(flag)
                if tile == 4:
                    lever = Lever(column_num * tile_size, row_num * tile_size)
                    lever_group.add(lever)
                column_num += 1
            row_num += 1
    
    # draws the playing board on the screen
    def draw(self):
        for tile in self.tile_list:
            screen.blit(tile[0], tile[1])

class Spike(pygame.sprite.Sprite):
    def __init__(self, x, y):
        pygame.sprite.Sprite.__init__(self)
        spike_img = pygame.image.load("assets/spike.png")
        self.image = pygame.transform.scale(spike_img, (tile_size, tile_size / 1.5))
        self.rect = self.image.get_rect()
        self.rect.x = x
        self.rect.y = y

class Flag(pygame.sprite.Sprite):
    def __init__(self, x, y):
        pygame.sprite.Sprite.__init__(self)
        flag_img = pygame.image.load("assets/flag.png")
        self.image = pygame.transform.scale(flag_img, (tile_size, tile_size))
        self.rect = self.image.get_rect()
        self.rect.x = x
        self.rect.y = y

class Lever(pygame.sprite.Sprite):
    def __init__(self, x, y):
        pygame.sprite.Sprite.__init__(self)
        lever_img = pygame.image.load("assets/lever.png")
        self.image = pygame.transform.scale(lever_img, (tile_size, tile_size))
        self.rect = self.image.get_rect()
        self.rect.x = x
        self.rect.y = y

# game setup
player = Player(105, 570)
spike_group = pygame.sprite.Group()
flag_group = pygame.sprite.Group()
lever_group = pygame.sprite.Group()
start_menu = Start(0, 0)

# load in level data
pickle_in = open(f"levels/l{level}_data.pkl", "rb")
world = World(pickle.load(pickle_in))

# reset level after completing a level
def reset_level(level):
    global world
    spike_group.empty()
    flag_group.empty()
    lever_group.empty()
    pickle_in = open(f"levels/l{level}_data.pkl", "rb")
    world = World(pickle.load(pickle_in))

# game loop
running = True
while running:
    screen.fill((0, 0, 0))
    runbackground()
    if game_state == 1:
        start_menu.draw()
    else:
        world.draw()
        spike_group.draw(screen)
        if dark_state == 0:
            screen.blit(dark_img, (0, 0))
        lever_group.draw(screen)
        game_state, dark_state = player.update(game_state, dark_state)
        flag_group.draw(screen)

    if game_state == 2:
        level += 1
        reset_level(level)
        game_state = 0

    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False
        elif event.type == KEYDOWN:
            if event.key == K_SPACE and game_state == 1:
                game_state = 0

    pygame.display.update()

pygame.quit()